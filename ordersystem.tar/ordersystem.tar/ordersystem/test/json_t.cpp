#include<iostream>
#include<string>
#include<jsoncpp/json/json.h>

using namespace std;

//序列化部分
string serialize()
{
 const char* name="rabbit";
 int id=12345;
 const char *sex="female";
 int score[3]={88,66,99};

 Json::Value val;
 val["姓名"]=name;
 val["学号"]=id;
 val["性别"]=sex;
 
  for(int i=0;i<3;++i)
 {
  val["成绩"].append(score[i]);
 }
 //Json::StyledWriter writer;
 Json::FastWriter writer;
 string str=writer.write(val);
 cout<< str <<endl;
 return str;
}

//反序列化部分
void deserialize(std::string &str)
{
 Json::Value val;
 Json::Reader reader;
 bool ret=reader.parse(str,val);
 if(ret==false)
 {
  cout<<"parse json failed~\n"<<endl;
  return; 
 }
  cout<<val["姓名"].asString()<<endl;
  cout<<val["性别"].asString()<<endl;
  cout<<val["学号"].asInt()<<endl;
  int num=val["成绩"].size();
  for(int i=0;i<num; ++i)
  {
   cout<<val["成绩"][i].asInt()<<endl;
  }
  return;
}

int main()
{
 string str=serialize();
 deserialize(str);
 return 0;
}

